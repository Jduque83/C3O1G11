
package logica;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import persistencia.ConexionBD;

/**
 *
 * @author Julian Duque G
 */
public class Cancion {
    private String numCancion;
    private String nombreCancion;
    private String genero;
    private Integer annioSalida;
    private String artista;

    public Cancion() {
    }

    public Cancion(String numCancion, String nombreCancion, String genero, Integer annioSalida, String artista) {
        this.numCancion = numCancion;
        this.nombreCancion = nombreCancion;
        this.genero = genero;
        this.annioSalida = annioSalida;
        this.artista = artista;
    }

    public String getNumCancion() {
        return numCancion;
    }

    public void setNumCancion(String numCancion) {
        this.numCancion = numCancion;
    }

    public String getNombreCancion() {
        return nombreCancion;
    }

    public void setNombreCancion(String nombreCancion) {
        this.nombreCancion = nombreCancion;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Integer getAnnioSalida() {
        return annioSalida;
    }

    public void setAnnioSalida(Integer annioSalida) {
        this.annioSalida = annioSalida;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    @Override
    public String toString() {
        return "Cancion{" + "numCancion=" + numCancion + ", nombreCancion=" + nombreCancion + ", genero=" + genero + ", annioSalida=" + annioSalida + ", artista=" + artista + '}';
    }
    
    
    public List<Cancion> consultarCanciones(){
    List<Cancion> canciones = new ArrayList<>();
    ConexionBD conexion= new ConexionBD();
    String sql="SELECT * FROM canciones;";
    ResultSet rs=conexion.consultarBD(sql);
   try{
       Cancion c;
       while(rs.next()){
           c= new Cancion();
           c.setNumCancion(rs.getString("numCancion"));
           c.setNombreCancion(rs.getString("nombreCancion"));
           c.setGenero(rs.getString("genero"));
           c.setAnnioSalida(rs.getInt("annioSalida"));
           c.setArtista(rs.getString("artista"));
           canciones.add(c);
           
           
       }
   }catch(SQLException ex){
       System.out.println(ex.getMessage());
   }finally{
   conexion.cerrarConexion();
   }
    
    return canciones;
    }
    
    public boolean guardarCancion(){
        boolean exito = false;
        ConexionBD conexion = new ConexionBD();
        String sql= "INSERT INTO canciones (numCancion, nombreCancion, genero, annioSalida, artista) VALUES('"+numCancion+"', '"+nombreCancion+"', '"+genero+"',"+annioSalida+", '"+artista+"');";
        
        if(conexion.setAutoCommitBD(false)){
            if(conexion.insertarBD(sql)){
            exito=true;
            conexion.commitBD();
            conexion.cerrarConexion();
            }else{
                conexion.rollbackBD();
                conexion.cerrarConexion();
            }
            
        }else{
            conexion.cerrarConexion();
        }
        
        return exito;
    }
    
    public boolean actualizarCancion(){
        boolean exito = false;
        ConexionBD conexion = new ConexionBD();
        String sql= "UPDATE canciones SET nombreCancion='"+nombreCancion+"', genero='"+genero+"', annioSalida="+annioSalida+", artista='"+artista+"' WHERE numCancion='"+numCancion+"';";
        
        if(conexion.setAutoCommitBD(false)){
            if(conexion.actualizarBD(sql)){
            exito=true;
            conexion.commitBD();
            conexion.cerrarConexion();
            }else{
                conexion.rollbackBD();
                conexion.cerrarConexion();
            }
            
        }else{
            conexion.cerrarConexion();
        }
        
        return exito;
    }
    
    public boolean eliminarCancion(){
        boolean exito = false;
        ConexionBD conexion = new ConexionBD();
        String sql= "DELETE FROM canciones WHERE numCancion='"+numCancion+"';";
        
        if(conexion.setAutoCommitBD(false)){
            if(conexion.actualizarBD(sql)){
            exito=true;
            conexion.commitBD();
            conexion.cerrarConexion();
            }else{
                conexion.rollbackBD();
                conexion.cerrarConexion();
            }
            
        }else{
            conexion.cerrarConexion();
        }
        
        return exito;
    }
    
}
