package logica;

import java.util.List;

/**
 *
 * @author Julian Duque G
 */
public class DemoRockola {
    public static void main(String[] args) {
        
        Cancion c= new Cancion();
        c.setNumCancion("2");
        c.setNombreCancion("Maldita primavera");
        c.setGenero("Plancha");
        c.setAnnioSalida(1982);
        c.setArtista("Yury");
        c.guardarCancion();
   //     System.out.println(c.actualizarCancion());
   //       System.out.println(c.eliminarCancion());
        
        
        
        List<Cancion>canciones=c.consultarCanciones();
        for (Cancion cx : canciones) {
            System.out.println(cx.toString());
        }
                
        
    }
    
}
